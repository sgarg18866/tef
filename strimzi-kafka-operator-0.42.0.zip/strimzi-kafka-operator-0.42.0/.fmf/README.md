## FMF

Flexible Metadata Format [(doc)](https://fmf.readthedocs.io/en/stable/overview.html#description)

This [folder](.) and version [file](version) are required for testing-farm and packit integration.
To see more information about testing-farm please read this [documentation](../systemtest/tmt/README.md).