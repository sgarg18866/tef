Run Jenkins pipeline on ppc64le VM

Nightly builds will run on ppc64le VM to build the artifacts and run acceptance profile of system test on master branch at 12:00 am EST each day.
Link to access Jenkins builds on ppc64le VM: http://140.211.168.45:8080/job/strimzi-kafka-operator/job/strimzi-kafka-operator/

Note: This link may change in the future.
