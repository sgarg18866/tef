# Run Jenkins pipeline on s390x VM

Nightly builds will be running on s390x VM to build the artifacts and run `acceptance` profile of system test on master branch at 12:00 am EST each day.

The below link can be used to access the Jenkins builds on s390x VMs:
https://148.100.84.211/job/strimzi-kafka-operator/job/Strimzi_Kafka_Operator_ST/

_**Note: This link may change in the future.**_